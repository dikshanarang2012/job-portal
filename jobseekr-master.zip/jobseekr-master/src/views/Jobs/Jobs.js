import React from "react";
import JobPost from "../../components/JobPost/JobPost";
import "./Jobs.css";

function Jobs() {
  return (
    <React.Fragment>
      <div class="container post__container mt-5">
        <h4 className="mb-4">JOBS</h4>
        <JobPost
          title="Front end Developer"
          company="Google"
          date="1st June 2020"
          bio="react hirirng"
          lastUpdate="1st June 2020"
        />
        <JobPost
          title="Front end Developer"
          company="Google"
          date="1st June 2020"
          bio="react hirirng"
          lastUpdate="1st June 2020"
        />
        <JobPost
          title="Front end Developer"
          company="Google"
          date="1st June 2020"
          bio="react hirirng"
          lastUpdate="1st June 2020"
        />
        <JobPost
          title="Front end Developer"
          company="Google"
          date="1st June 2020"
          bio="react hirirng"
          lastUpdate="1st June 2020"
        />
        <JobPost
          title="Front end Developer"
          company="Google"
          date="1st June 2020"
          bio="react hirirng"
          lastUpdate="1st June 2020"
        />
        <JobPost
          title="Front end Developer"
          company="Google"
          date="1st June 2020"
          bio="react hirirng"
          lastUpdate="1st June 2020"
        />
        <JobPost
          title="Front end Developer"
          company="Google"
          date="1st June 2020"
          bio="react hirirng"
          lastUpdate="1st June 2020"
        />
        <JobPost
          title="Front end Developer"
          company="Google"
          date="1st June 2020"
          bio="react hirirng"
          lastUpdate="1st June 2020"
        />
        <JobPost
          title="Front end Developer"
          company="Google"
          date="1st June 2020"
          bio="react hirirng"
          lastUpdate="1st June 2020"
        />
        <JobPost
          title="Front end Developer"
          company="Google"
          date="1st June 2020"
          bio="react hirirng"
          lastUpdate="1st June 2020"
        />
        <JobPost
          title="Front end Developer"
          company="Google"
          date="1st June 2020"
          bio="react hirirng"
          lastUpdate="1st June 2020"
        />
        <JobPost
          title="Front end Developer"
          company="Google"
          date="1st June 2020"
          bio="react hirirng"
          lastUpdate="1st June 2020"
        />
      </div>
    </React.Fragment>
  );
}

export default Jobs;
